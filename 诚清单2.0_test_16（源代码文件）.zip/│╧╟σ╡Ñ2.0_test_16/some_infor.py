# -*- coding: utf-8 -*-
# 获取电脑的一些信息
import time
import wmi  # 获取硬盘 cpu 主板 mac bios等硬件信息模块
import pythoncom
import sys
import os
import json
import socket
import re  # 导入正则表达式模块
import ast  # 列表包裹在引号内，提取出来变成列表  字符转列表 字符转字典等
import getpass  # 获取当前用户名
import platform  # 获取操作系统版本相关
import wmi  # 获取硬盘 cpu 主板 mac bios等硬件信息模块
# 获取本机公网ip的四种方法
from urllib.request import urlopen
import pymysql  # mysql服务器

# 计算程序运行时间 @get_time_consuming
def get_time_consuming(func):
    '''
    from test_time import decorator   先导入
    TODO @get_time_consuming
    :param func:
    :return:
    '''
    def inner(*args, **kwargs):  # def function():
        # 获取时间距离1970-1-1 0:0:1的时间差
        begin = time.time()
        func(*args, **kwargs)
        end = time.time()
        result = end - begin
        # print(f'函数执行完成耗时：{result}')
        print('函数执行完成耗时：{:0.3f}秒'.format(result))
    return inner

# 获取当前时间
def get_now_time():
    try:
        tf = time.time()
        t = time.localtime(tf)
        # 时间戳转换方法
        return time.strftime('%Y-%m-%d %H:%M:%S', t)
    except:
        return None

# 硬盘信息的查询  返回硬盘号
def get_diskNum():
    # print("硬盘信息的查询  返回硬盘号")
    try:
        # 必须添加初始化函数和去初始化函数 否则 WMI 失败
        pythoncom.CoInitialize()
        c = wmi.WMI()
        listc = []
        for physical_disk in c.Win32_DiskDrive():
            # print(physical_disk.SerialNumber)
            listc.append(physical_disk.SerialNumber)
        pythoncom.CoUninitialize()
        # print(listc)
        return listc
    except Exception as e:
        print("diskNum_find 出错", e)
        return None

# 获取外网IP地址，Extranet_IP
def get_Extranet_IP():  # return str 10.0.23.91 来源
    # time.sleep(2)
    try:
        my_ip = json.load(urlopen('http://jsonip.com'))['ip']
        if len(my_ip) >= 7:
            return my_ip, 'jsonip'

        my_ip = json.load(urlopen('http://httpbin.org/ip'))['origin']
        if len(my_ip) >= 7:
            return my_ip, 'httpbin'

        my_ip = json.load(urlopen('https://api.ipify.org/?format=json'))['ip']
        if len(my_ip) >= 7:
            return my_ip, 'ipify'

        my_ip = urlopen('http://ip.42.pl/raw').read()
        my_ip = str(my_ip)
        my_ip = my_ip[2:-1]
        if len(my_ip) >= 7:
            return my_ip, 'ip.42'
    except:
        return None, None

# 获取内网 IP
def get_Intranet_IP():
    try:
        s = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    except:
        return None
    finally:
        s.close()
    # print(ip)
    return ip

# 获取设备名称
def get_hostname():
    try:
        hostname = socket.gethostname()
        return hostname
    except:
        return None

# 获取用户名
def get_system_username():
    try:
        user_name = getpass.getuser()  # 获取当前用户名
        return user_name
    except:
        return None

# 获取 系统
def get_system_Version():
    try:
        sysstr = platform.platform()
        # print(type(sysstr), sysstr)
        return sysstr
    except:
        return None

# 接收广告(tuplel类型) 并更新本地数据， 主程序每次从本地数据读取, 如果未联网 则从本地读取
def advertise_infor_receive():
    try:
        conn = pymysql.connect(host='rm-bp114m07t2e13i30i9o.mysql.rds.aliyuncs.com',
                               port=3306, user='use_cqd000', password='Cqd123456', db='chengqingdan2021',
                               charset='utf8')
        status = conn.server_status  # 获取连接状态
        cursor = conn.cursor()
        sql = '''
            select * from advertise;
        '''
        effect_row = cursor.execute(sql)
        cuuall = cursor.fetchall()  # tuple 类型
        if cuuall:
            # 更新数据
            advertiseDict = {}
            advertiseDict['advertise'] = cuuall
            # print('2', advertiseDict['advertise'])  # 字典 元组
            # 写入
            with open(r".\data\main_data\advertiseDict.db", "w", encoding=None) as f:
                json.dump(advertiseDict, f, indent=4, sort_keys=True)  # 传入文件描述符，和dumps一样的结果

        cursor.close()  # 4.关闭游标
        conn.close()  # 5.关闭连接
    except Exception as e:
        print("连接失败！", e)
        # # 先读取数据
        with open(r".\data\main_data\advertiseDict.db", "r", encoding=None) as f:
            advertiseDict = json.load(f)  # 字典 列表
        # 读取 返回元组


if __name__ == '__main__':
    # print(get_Extranet_IP()[0])
    # get_Intranet_IP()
    # print(get_hostname())
    # print(get_system_name())
    # print(get_now_time())
    # print(get_system_Version())
    # print(get_system_username())
    # print(len(get_system_Version()), get_system_Version())
    pass